# Project: HeartBeat Sensor 

# Materials Required:
Ardiuno, Pulse Sensor, Bluethooth Module, Buzzer, Resistors, Capcitors, Bread Board, Connectors.
Ide: Arduino

# Images:
<img width="390" alt="image" src="https://github.com/YashDaga17/HeartBeat/assets/72146802/5764cf28-d2dd-4092-9a50-97dca53521ea">

# Results 
At the end we are able to see the number of heart beats on our mobile phone.

